import requests
import socks
import socket
import threading
import os
import time
import random

# Astig na banner
BANNER = """
██████╗ ██████╗  ██████╗ ██╗  ██╗██╗   ██╗
██╔══██╗██╔══██╗██╔═══██╗██║ ██╔╝╚██╗ ██╔╝
██████╔╝██████╔╝██║   ██║█████╔╝  ╚████╔╝ 
██╔═══╝ ██╔══██╗██║   ██║██╔═██╗   ╚██╔╝  
██║     ██║  ██║╚██████╔╝██║  ██╗   ██║   
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   
REAL PROXY VALIDATION CHECKER - KORI EDITION
"""

# Create folder for valid proxies
OUTPUT_FOLDER = "checked_proxies"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)
VALID_PROXIES_FILE = os.path.join(OUTPUT_FOLDER, "valid_proxies.txt")

# Function to check if a proxy is valid
def check_proxy(proxy, proxy_type):
    try:
        ip, port = proxy.split(":")
        port = int(port)
        
        if proxy_type == "http":
            proxies = {"http": f"http://{proxy}", "https": f"https://{proxy}"}
            response = requests.get("https://www.google.com", proxies=proxies, timeout=5)
        else:
            socks.set_default_proxy(proxy_type, ip, port)
            socket.socket = socks.socksocket
            test_socket = socket.socket()
            test_socket.connect(("www.google.com", 80))
            test_socket.close()

        print(f"\033[92m[VALID] {proxy}\033[0m")  # Green color
        with open(VALID_PROXIES_FILE, "a") as f:
            f.write(proxy + "\n")

    except Exception:
        print(f"\033[91m[INVALID] {proxy}\033[0m")  # Red color

# Function to determine proxy type
def detect_proxy_type(choice):
    if choice == "1":
        return "http"
    elif choice == "2":
        return socks.SOCKS4
    elif choice == "3":
        return socks.SOCKS5
    else:
        return "http"

# Main function
def main():
    print(BANNER)

    # Inline menu
    print("\n📌 **Pumili ng Proxy Type:**")
    print("[1] HTTP")
    print("[2] SOCKS4")
    print("[3] SOCKS5")
    proxy_choice = input("👉 Enter choice (1/2/3): ").strip()

    file_path = input("📂 Enter proxy file path: ").strip()

    try:
        with open(file_path, "r") as file:
            proxies = [line.strip() for line in file if line.strip()]
        
        threads = []
        for proxy in proxies:
            proxy_type = detect_proxy_type(proxy_choice)
            t = threading.Thread(target=check_proxy, args=(proxy, proxy_type))
            t.start()
            threads.append(t)
            time.sleep(random.uniform(1, 3))  # Random delay 1-3 sec
        
        for t in threads:
            t.join()
        
        print(f"\n✅ Proxy checking complete! Valid proxies saved in '{VALID_PROXIES_FILE}'.\n")

    except FileNotFoundError:
        print("\033[91m❌ Error: File not found. Please enter a valid path.\033[0m")

if __name__ == "__main__":
    main()