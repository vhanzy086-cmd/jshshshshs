import telebot
import os
import threading
import json
from datetime import datetime
import chardet

# 🔑 Ilagay ang iyong Telegram Bot Token dito
TOKEN = "8025815564:AAGICpN84zGEIu5Bg9ICp2YluLTgxrSuhwg"
bot = telebot.TeleBot(TOKEN)

# 🎯 Listahan ng specific domains na hahanapin
TARGET_DOMAINS = [
    "mtacc.mobilelegends.com",
    "www.roblox",
    "authgop.garena.com",
    "100082.connect.garena.com"
]

# 📂 Pangalan ng database file
DB_FILE = "extracted_results.json"

# 📌 Function para alamin ang tamang encoding ng file
def detect_encoding(file_path):
    with open(file_path, "rb") as f:
        raw_data = f.read(10000)  # Sample size
    result = chardet.detect(raw_data)
    return result["encoding"] or "utf-8"  # Default to utf-8 if detection fails

# 📌 Function para mag-save ng extracted data sa JSON file
def save_to_json(data):
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as file:
            try:
                existing_data = json.load(file)
            except json.JSONDecodeError:
                existing_data = {}
    else:
        existing_data = {}

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    existing_data[timestamp] = data

    with open(DB_FILE, "w", encoding="utf-8") as file:
        json.dump(existing_data, file, indent=4)

# 🔍 Function para mag-extract ng specific domains mula sa log file
def extract_specific_domains(file_path):
    encoding = detect_encoding(file_path)  # Alamin ang tamang encoding
    results = {domain: [] for domain in TARGET_DOMAINS}  # Dictionary para sa output

    try:
        with open(file_path, "r", encoding=encoding, errors="ignore") as file:
            for line in file:
                for domain in TARGET_DOMAINS:
                    if domain in line:
                        results[domain].append(line.strip())  # I-save ang buong linya kung nakita ang domain
    except Exception as e:
        return {"error": f"Error reading file: {e}"}

    return results

# 🚀 Function para sa background processing gamit ang threading
def process_file(message, file_path):
    try:
        bot.send_message(message.chat.id, "🔄 **Processing log file...**")

        extracted_data = extract_specific_domains(file_path)
        os.remove(file_path)  # Linisin ang file pagkatapos basahin

        if "error" in extracted_data:
            bot.send_message(message.chat.id, f"⚠️ **Error:** {extracted_data['error']}")
            return

        save_to_json(extracted_data)  # I-save ang extracted data sa JSON file

        response = "✅ **Extraction Complete!**\n\n"
        found = False

        for domain, lines in extracted_data.items():
            if lines:
                found = True
                response += f"📌 **{domain}**\n" + "\n".join(lines) + "\n\n"  # Lahat ng matching lines ipapakita

        if not found:
            response = "❌ **Walang nahanap na matching domains sa log file.**"

        # 📌 Hatiin ang output kung masyadong mahaba (Telegram message limit: 4096 characters)
        for i in range(0, len(response), 4000):
            bot.send_message(message.chat.id, response[i:i+4000])

    except Exception as e:
        bot.send_message(message.chat.id, f"⚠️ **Unexpected Error:** {e}")

# 📩 Command /start
@bot.message_handler(commands=['start'])
def start_message(message):
    bot.reply_to(message, "📂 **I-upload mo ang log file, at hahanapin ko ang specific domains sa loob.**")

# 📂 Handler para sa file uploads
@bot.message_handler(content_types=['document'])
def handle_docs(message):
    try:
        file_id = message.document.file_id
        file_info = bot.get_file(file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        file_name = "uploaded_log.txt"
        with open(file_name, "wb") as new_file:
            new_file.write(downloaded_file)

        # 🔥 Gamitin ang threading para mabilis at hindi bumagal ang bot
        thread = threading.Thread(target=process_file, args=(message, file_name))
        thread.start()

        bot.reply_to(message, "⏳ **Processing... Sandali lang!**")

    except Exception as e:
        bot.reply_to(message, f"⚠️ **Error sa pag-upload:** {e}")

print("🚀 Bot is running...")
bot.polling()