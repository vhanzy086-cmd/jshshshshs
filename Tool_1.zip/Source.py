import os
import sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Configuration
SALT_LENGTH = 16
NONCE_LENGTH = 12
HEADER = b'ENCv2'
KEY_FILE = 'encryption_key.bin'

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

def generate_key():
    return AESGCM.generate_key(bit_length=256)

def save_key(key):
    with open(KEY_FILE, 'wb') as f:
        f.write(key)

def load_key():
    with open(KEY_FILE, 'rb') as f:
        return f.read()

def encrypt_file():
    clear_screen()
    print("[ FILE ENCRYPTION ]\n")
    
    input_file = input("Input file to encrypt: ").strip()
    output_file = input("Output file name: ").strip()
    
    try:
        # Generate new key for each encryption
        key = generate_key()
        salt = os.urandom(SALT_LENGTH)
        nonce = os.urandom(NONCE_LENGTH)
        
        aesgcm = AESGCM(key)
        
        with open(input_file, 'rb') as f:
            plaintext = f.read()
        
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)
        
        # Save key automatically
        save_key(key)
        
        with open(output_file, 'wb') as f:
            f.write(HEADER + salt + nonce + ciphertext)
        
        input(f"\nFile encrypted! Key saved to {KEY_FILE}. Press enter to continue...")
    
    except Exception as e:
        input(f"\nError: {str(e)} Press enter to continue...")

def decrypt_file():
    clear_screen()
    print("[ FILE DECRYPTION ]\n")
    
    input_file = input("Input file to decrypt: ").strip()
    output_file = input("Output file name: ").strip()
    
    try:
        key = load_key()
        
        with open(input_file, 'rb') as f:
            data = f.read()
        
        if not data.startswith(HEADER):
            raise ValueError("Invalid encrypted file format")
        
        salt = data[len(HEADER):len(HEADER)+SALT_LENGTH]
        nonce = data[len(HEADER)+SALT_LENGTH:len(HEADER)+SALT_LENGTH+NONCE_LENGTH]
        ciphertext = data[len(HEADER)+SALT_LENGTH+NONCE_LENGTH:]
        
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        
        with open(output_file, 'wb') as f:
            f.write(plaintext)
        
        input("\nFile decrypted successfully! Press enter to continue...")
    
    except Exception as e:
        input(f"\nError: {str(e)} Press enter to continue...")

def main_menu():
    while True:
        clear_screen()
        print("""
        ==== AUTO-ENCRYPTOR ====
        1. Encrypt File (Generate New Key)
        2. Decrypt File (Use Existing Key)
        3. Exit
        """)
        choice = input("Enter your choice (1-3): ")
        
        if choice == '1':
            encrypt_file()
        elif choice == '2':
            decrypt_file()
        elif choice == '3':
            sys.exit()
        else:
            input("Invalid choice! Press enter to continue...")

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit()