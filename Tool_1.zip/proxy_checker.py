import requests
import socket
import time
import os
from concurrent.futures import ThreadPoolExecutor

# Color codes
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
PURPLE = '\033[95m'
RESET = '\033[0m'

def validate_proxy(proxy):
    try:
        if '://' in proxy:
            protocol, address = proxy.split('://')
        else:
            protocol = 'http'
            address = proxy
        
        ip, port = address.split(':')
        socket.inet_aton(ip)
        if not (1 <= int(port) <= 65535):
            return False
        return True
    except (ValueError, socket.error):
        return False

def check_proxy(proxy, timeout=15):
    test_urls = [
        ('http://httpbin.org/ip', True),
        ('https://api.ipify.org?format=json', True),
        ('http://www.google.com', False)
    ]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Android 13; Mobile)',
        'Accept-Language': 'en-US,en;q=0.9'
    }
    
    try:
        protocol = 'http'
        if '://' in proxy:
            protocol, proxy_addr = proxy.split('://')
            protocol = protocol.lower()
        else:
            proxy_addr = proxy
        
        if not validate_proxy(proxy):
            return None
        
        proxies = {}
        if protocol in ['http', 'https']:
            proxies = {
                'http': f'http://{proxy_addr}',
                'https': f'http://{proxy_addr}'
            }
        elif protocol in ['socks4', 'socks5']:
            proxies = {
                'http': f'{protocol}://{proxy_addr}',
                'https': f'{protocol}://{proxy_addr}'
            }
        else:
            return None
        
        success = 0
        external_ip = None
        total_latency = 0
        
        for url, check_ip in test_urls:
            try:
                start = time.time()
                response = requests.get(
                    url,
                    proxies=proxies,
                    headers=headers,
                    timeout=timeout
                )
                latency = time.time() - start
                total_latency += latency
                
                if response.status_code == 200:
                    if check_ip:
                        current_ip = response.json().get('ip', '')
                        if not external_ip:
                            external_ip = current_ip
                        elif current_ip != external_ip:
                            return None
                    success += 1
            except:
                continue
        
        if success >= 2:
            avg_latency = total_latency / success
            return {
                'proxy': f'{protocol}://{proxy_addr}',
                'protocol': protocol.upper(),
                'latency': round(avg_latency, 2),
                'ip': external_ip
            }
    except Exception as e:
        return None
    
    return None

def main():
    print(f"{CYAN}╔{'═'*40}╗{RESET}")
    print(f"{CYAN}║{PURPLE}      🛡 PROXY CHECKER FOR PYDROID3 🛡      {CYAN}║{RESET}")
    print(f"{CYAN}╚{'═'*40}╝{RESET}\n")
    
    input_path = input(f"{CYAN}[?] Enter input file path: {RESET}").strip()
    output_path = input(f"{CYAN}[?] Enter output file path: {RESET}").strip()
    timeout = int(input(f"{CYAN}[?] Timeout (seconds) [{YELLOW}15{RESET}{CYAN}]: {RESET}") or 15)
    workers = int(input(f"{CYAN}[?] Number of threads (1-20) [{YELLOW}10{RESET}{CYAN}]: {RESET}") or 10)
    
    print(f"\n{CYAN}╔{'═'*15}🛡  Scanning Proxies 🛡{'═'*15}╗{RESET}\n")
    
    try:
        with open(input_path, 'r') as f:
            proxies = list({line.strip() for line in f if line.strip()})
    except FileNotFoundError:
        print(f"\n{RED}✗ ERROR: File not found at path '{input_path}'{RESET}")
        return
    except Exception as e:
        print(f"\n{RED}✗ Error reading file: {str(e)}{RESET}")
        return
    
    if not proxies:
        print(f"\n{RED}✗ No proxies found in input file!{RESET}")
        return
    
    working = []
    
    try:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(check_proxy, proxy, timeout): proxy for proxy in proxies}
            
            for future in futures:
                proxy = futures[future]
                try:
                    result = future.result()
                    if result:
                        working.append(result)
                        print(f"{GREEN}✓ {CYAN}{result['proxy']}{RESET} | {YELLOW}Latency: {result['latency']}s{RESET} | {PURPLE}IP: {result['ip']}{RESET}")
                    else:
                        print(f"{RED}✗ {proxy}{RESET}")
                except Exception as e:
                    print(f"{YELLOW}! {RED}Error checking {proxy}{RESET}")
    except KeyboardInterrupt:
        print(f"\n{YELLOW}⚠ Operation cancelled by user!{RESET}")
        return
    
    if working:
        try:
            with open(output_path, 'w') as f:
                for proxy in working:
                    f.write(f"{proxy['proxy']}\n")
            
            print(f"\n{CYAN}╔{'═'*12}🛡  Scan Results 🛡{'═'*12}╗{RESET}")
            print(f"{CYAN}║ {YELLOW}Total proxies checked: {CYAN}{len(proxies)}{RESET}")
            print(f"{CYAN}║ {GREEN}Working proxies found: {CYAN}{len(working)}{RESET}")
            print(f"{CYAN}║ {PURPLE}Success rate: {CYAN}{(len(working)/len(proxies)*100):.1f}%{RESET}")
            print(f"{CYAN}║ {YELLOW}Output saved to: {CYAN}{output_path}{RESET}")
            print(f"{CYAN}╚{'═'*32}╝{RESET}")
        except Exception as e:
            print(f"\n{RED}✗ Error saving results: {str(e)}{RESET}")
    else:
        print(f"\n{RED}✗ No working proxies found!{RESET}")

if __name__ == '__main__':
    main()