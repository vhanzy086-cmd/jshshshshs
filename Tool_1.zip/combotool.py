import os
import string
import re
from tqdm import tqdm

# ANSI escape codes for colors
YELLOW_BOLD = '\033[1;33m'
GREEN_BOLD = '\033[1;32m'
GREEN = '\033[92m'
RESET = '\033[0m'
RED = '\033[91m'
RED_BOLD = '\033[1;91m'
VIOLET_BOLD = '\033[1;35m'
CYAN = '\033[96m'
CYAN_BOLD = '\033[1;36m'
BLUE_BOLD = '\033[1;34m'

# Color codes for sorter feature
SORTER_RED = '\033[91m'
SORTER_GREEN = '\033[92m'
SORTER_YELLOW = '\033[93m'
SORTER_BLUE = '\033[94m'
SORTER_MAGENTA = '\033[95m'
SORTER_CYAN = '\033[96m'
SORTER_RESET = '\033[0m'
SORTER_BOLD = '\033[1m'
SORTER_UNDERLINE = '\033[4m'

def is_valid_password(password):
    """
    Checks if a password meets the criteria:
    - 6 or more characters long
    - Contains no special characters or whitespace
    - Contains at least one uppercase letter
    - Contains at least one lowercase letter
    """
    if len(password) < 6:
        return False

    has_uppercase = False
    has_lowercase = False

    for char in password:
        if char in string.punctuation or char in string.whitespace:
            # Contains special characters or whitespace
            return False
        if char.isupper():
            has_uppercase = True
        elif char.islower(): # Use elif because a char can't be both
            has_lowercase = True
        # Digits are allowed, no need for an explicit check unless we wanted to require one

    # Must have at least one uppercase letter AND at least one lowercase letter
    if not has_uppercase or not has_lowercase:
        return False

    # If all checks pass
    return True

def process_combo_file():
    """
    Prompts the user for a file, processes it using is_valid_password,
    and saves valid combos.
    """
    input_filepath = input(f"{CYAN}Enter the path to your email:pass combo file: {RESET}").strip()

    if not os.path.exists(input_filepath):
        print(f"{RED}Error: File not found at '{input_filepath}'{RESET}")
        return

    processed_count = 0
    fixed_combos = [] # Store valid combos here temporarily
    total_lines = 0

    # Get total lines for progress bar
    try:
        with open(input_filepath, 'r', encoding='utf-8', errors='ignore') as temp_file:
            for _ in temp_file:
                total_lines += 1
    except Exception as e:
        print(f"{RED}Error reading file to determine total lines: {e}{RESET}")
        return

    print(f"{YELLOW_BOLD}Processing file '{input_filepath}'...{RESET}")

    try:
        with open(input_filepath, 'r', encoding='utf-8', errors='ignore') as infile:
             for line in tqdm(infile, total=total_lines, desc="Processing Combos", ascii=False, ncols=100,
                          bar_format='{l_bar}{bar}{r_bar} | {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):
                processed_count += 1
                line = line.strip()

                if not line: # Skip empty lines
                    continue

                parts = line.split(':', 1) # Split only on the first colon

                if len(parts) == 2:
                    email = parts[0].strip()
                    password = parts[1].strip()

                    if email and password and is_valid_password(password):
                        fixed_combos.append(f"{email}:{password}")
                else:
                    # Optionally log or print lines that don't match the format
                    # print(f"{YELLOW_BOLD}Skipping malformed line: {line}{RESET}")
                    pass # Just skip lines not in email:pass format

        fixed_count = len(fixed_combos)
        # Modified output filename format as per request
        output_filename = f"x{fixed_count}_moontonvalid.txt"
        output_filepath = os.path.join(os.path.dirname(input_filepath), output_filename)


        if fixed_count > 0:
            try:
                with open(output_filepath, 'w', encoding='utf-8') as outfile:
                    for combo in fixed_combos:
                        outfile.write(combo + '\n')
                print(f"\n{GREEN_BOLD}Valid Format Extracted!{RESET}") # Added newline for cleaner output after tqdm
                print(f"{CYAN}Processed: {processed_count}{RESET}")
                print(f"{GREEN_BOLD}Valids: {fixed_count}{RESET}")
                print(f"{GREEN_BOLD}Results Saved to: {output_filepath}{RESET}")
            except IOError as e:
                print(f"\n{RED}Error saving output file '{output_filepath}': {e}{RESET}") # Added newline
                print(f"{YELLOW_BOLD}Processed: {processed_count}{RESET}")
                print(f"{RED}Fixed: {fixed_count} (Saving failed){RESET}")
        else:
            print(f"\n{YELLOW_BOLD}No combos found that meet the password criteria.{RESET}") # Added newline
            print(f"{CYAN}Processed: {processed_count}{RESET}")
            print(f"{YELLOW_BOLD}Fixed: {fixed_count}{RESET}")


    except FileNotFoundError:
        # This should ideally be caught by the initial check, but good for robustness
        print(f"{RED}Error: File not found at '{input_filepath}' during processing.{RESET}")
    except Exception as e:
        print(f"{RED}An unexpected error occurred: {e}{RESET}")

def remove_double_slash(url):
    """Removes leading double slashes from a URL."""
    if url.startswith("//"):
        return url[2:]
    return url

def extract_credentials_from_slash_url(url):
    """Extracts the part after the last space in the URL which looks like email:pass or num:pass."""
    parts = url.split(' ')
    last_part = parts[-1] if parts else ""
    if ':' in last_part:  # Check if the last part contains a colon, indicating credentials
        return last_part
    return None

def extract_credentials_with_keyword(combo_file_path, keyword):
    """Searches for a keyword, then extracts credentials from matching lines, separating num:pass."""
    extracted_lines = 0
    extracted_numpass_lines = 0  # Initialize numpass counter
    lines_changed = 0  # Initialize lines_changed here
    total_lines = 0

    # Get total lines for progress bar
    try:
        with open(combo_file_path, 'r', encoding='utf-8', errors='ignore') as temp_file:
            for _ in temp_file:
                total_lines += 1
    except Exception as e:
        print(f"{RED}Error reading file to determine total lines: {e}{RESET}")
        return 0, [], [], 0, 0, 0  # Return counts as zero on failure, and lines_changed

    output_lines = []
    numpass_output_lines = []

    with open(combo_file_path, 'r', encoding='utf-8', errors='ignore') as infile:
        for line in tqdm(infile, total=total_lines, desc=f"Extracting keyword: {keyword}", ascii=False, ncols=100,
                          bar_format='{l_bar}{bar}{r_bar} | {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):
            line = line.strip()
            if keyword.lower() in line.lower():  # Case-insensitive keyword search
                original_line = line
                pre_cleanup_line = line
                line = re.sub(r'^(?:[^:]+:)?([^:]+:[^:]+)$', r'\1', line)  # Remove any prefix before mail:pass or num:pass
                cleaned_line = line.strip()

                if pre_cleanup_line != cleaned_line:  # if line changed then urls were removed.
                    lines_changed += 1  # Increment the counter

                match = re.search(r'([^:]+:[^:]+)$', cleaned_line)  # extract actual mail:pass or num:pass
                if match:
                    credentials = match.group(1)
                    if re.match(r'^\d+:', credentials):  # Check if it's num:pass
                        numpass_output_lines.append(credentials)  # Collect numpass credentials
                        extracted_numpass_lines += 1  # Increment numpass counter
                    else:
                        output_lines.append(credentials)  # Collect regular credentials
                        extracted_lines += 1

    return total_lines, output_lines, numpass_output_lines, extracted_lines, extracted_numpass_lines, lines_changed  # Return counts and lines_changed

def extract_credentials_from_slash_urls(combo_file_path):
    """Processes the combo file, extracts credentials from slash URLs, and saves to output."""
    try:
        extracted_lines = 0
        total_lines = 0
        slash_url_count = 0

        # Get total lines for progress bar
        try:
            with open(combo_file_path, 'r', encoding='utf-8', errors='ignore') as temp_file:
                for _ in temp_file:
                    total_lines += 1
        except Exception as e:
            print(f"{RED}Error reading file to determine total lines: {e}{RESET}")
            return False

        output_lines = []

        with open(combo_file_path, 'r', encoding='utf-8', errors='ignore') as infile:
            for line in tqdm(infile, total=total_lines, desc="Extracting from Slash URLs", ascii=False, ncols=100,
                              bar_format='{l_bar}{bar}{r_bar} | {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):
                url = line.strip()
                if "//" in url:
                    slash_url_count += 1
                    cleaned_url = remove_double_slash(url)
                    credentials = extract_credentials_from_slash_url(cleaned_url)
                    if credentials:
                        output_lines.append(credentials)
                        extracted_lines += 1

        output_file_path = generate_slash_output_file_path(combo_file_path)

        if extracted_lines > 0:
            try:
                with open(output_file_path, 'w', encoding='utf-8') as outfile:
                    outfile.write('\n'.join(output_lines) + '\n')

                print(f"\n{GREEN_BOLD}Credentials Successfully Extracted from Slash URLs!{RESET}") # Added newline
                print(f"{GREEN_BOLD} Total Processed Lines: {total_lines}{RESET}")
                print(f"{CYAN_BOLD} Saved Credentials: {extracted_lines}{RESET}")
                print(f"{RED_BOLD}URLs with slash: {RED_BOLD}{slash_url_count}{RESET}")  # Added URLs with slash count
                print(f"{YELLOW_BOLD} Saved to: {output_file_path}{RESET}")
                return True
            except IOError as e:
                 print(f"\n{RED}Error saving output file '{output_file_path}': {e}{RESET}") # Added newline
                 print(f"{GREEN_BOLD} Total Processed Lines: {total_lines}{RESET}")
                 print(f"{RED} Saved Credentials: {extracted_lines} (Saving failed){RESET}")
                 print(f"{RED_BOLD}URLs with slash: {RED_BOLD}{slash_url_count}{RESET}")  # Added URLs with slash count
                 return False
        else:
            print(f"\n{RED_BOLD}No credentials found in Slash URLs.{RESET}") # Added newline
            print(f"{GREEN_BOLD} Total Processed Lines: {total_lines}{RESET}")
            print(f"{CYAN_BOLD} Saved Credentials: {extracted_lines}{RESET}")
            print(f"{RED_BOLD}URLs with slash: {RED_BOLD}{slash_url_count}{RESET}")  # Added URLs with slash count
            # Don't create an empty file if nothing was found
            # print(f"{YELLOW_BOLD} Output file would have been: {output_file_path}{RESET}") # Optional: show potential filename
            return False

    except FileNotFoundError:
        print(f"{RED}Error: File not found at {combo_file_path}{RESET}")
        return False
    except Exception as e:
        print(f"{RED}An error occurred: {e}{RESET}")
        return False


def get_file_path():
    """Gets the combo file path from user input."""
    while True:
        file_path = input(f"{GREEN}Enter the path to your combo file:{RESET} ").strip()
        if file_path:
            if os.path.exists(file_path):
                if os.path.isfile(file_path):
                     return file_path
                else:
                    print(f"{RED}Error: The path exists but is not a file. Please enter a valid file path.{RESET}")
            else:
                print(f"{RED}Error: File does not exist. Please enter a valid file path.{RESET}")
        else:
            print(f"{RED}File path cannot be empty. Please try again.{RESET}")

def get_folder_path():
    """Gets the folder path from user input."""
    while True:
        folder_path = input(f"{GREEN}Enter the folder path:{RESET} ").strip()
        if folder_path:
            if os.path.exists(folder_path):
                if os.path.isdir(folder_path):
                    return folder_path
                else:
                     print(f"{RED}Error: The path exists but is not a folder. Please enter a valid folder path.{RESET}")
            else:
                print(f"{RED}Error: Folder does not exist. Please enter a valid folder path.{RESET}")
        else:
            print(f"{RED}Folder path cannot be empty. Please try again.{RESET}")


def get_keywords():
    """Gets multiple keywords from user input."""
    while True:
        keywords_input = input(f"{GREEN}Enter keywords to search for (comma-separated):{RESET} ").strip()
        if keywords_input:
            keywords = [keyword.strip() for keyword in keywords_input.split(',')]
            # Remove empty strings if user enters "keyword1,,keyword2"
            keywords = [k for k in keywords if k]
            if keywords:
                return keywords
            else:
                 print(f"{RED}Keywords cannot be empty. Please try again.{RESET}")
        else:
            print(f"{RED}Keywords cannot be empty. Please try again.{RESET}")


def generate_output_file_path(input_file_path, count, keyword):
    """Generates an automatic output file path with the count and keyword in the filename."""
    output_directory = os.path.dirname(input_file_path)
    keyword_safe = "".join(x if x.isalnum() or x in (' ', '-', '_') else "_" for x in keyword).strip() # make keyword safe for filename, allow spaces/hyphens/underscores
    if not keyword_safe: # Handle cases where keyword becomes empty after cleaning
         keyword_safe = "keyword"
    # Truncate keyword_safe if it's too long for a filename
    if len(keyword_safe) > 50:
        keyword_safe = keyword_safe[:50] + "..."

    output_file_name = f"x{count}_{keyword_safe}.txt"  # Include count in filename
    return os.path.join(output_directory, output_file_name)

def generate_numpass_output_file_path(input_file_path, count, keyword):
    """Generates an automatic output file path for numpass with count and keyword in filename."""
    output_directory = os.path.dirname(input_file_path)
    keyword_safe = "".join(x if x.isalnum() or x in (' ', '-', '_') else "_" for x in keyword).strip()
    if not keyword_safe:
         keyword_safe = "keyword"
    if len(keyword_safe) > 50:
        keyword_safe = keyword_safe[:50] + "..."
    output_file_name = f"x{count}numpass_{keyword_safe}.txt"  # Filename for numpass with count
    return os.path.join(output_directory, output_file_name)

def generate_slash_output_file_path(input_file_path):
    """Generates an automatic output file path for slash extracted credentials."""
    output_directory = os.path.dirname(input_file_path)
    input_filename_base = os.path.splitext(os.path.basename(input_file_path))[0]
    output_file_name = f"{input_filename_base}_slash_extracted.txt" # Include input filename base
    return os.path.join(output_directory, output_file_name)

def sorter_txt(file_path):
    """
    Extracts URL:USER:PASS lines from a text file.

    Args:
        file_path (str): The path to the text file.

    Returns:
        list: A list of strings in "URL:USER:PASS" format, or an empty list if an error occurs.
    """
    if not os.path.exists(file_path):
        print(f"{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}File not found: {file_path}{SORTER_RESET}")
        return []
    if not file_path.lower().endswith('.txt'):
        print(f"{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}Invalid file type: {file_path} (Not a .txt file){SORTER_RESET}")
        return []

    output_lines = []
    current_entry = {}

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file: # Added encoding and error handling
            for line in file:
                line = line.strip()
                if line.startswith("SOFT:"):  # Skip lines starting with SOFT:
                    continue
                elif line.startswith("URL:"):
                    current_entry['url'] = line[4:].strip()  # Extract URL
                elif line.startswith("USER:"):
                    current_entry['user'] = line[5:].strip()  # Extract USER
                elif line.startswith("PASS:"):
                    current_entry['pass'] = line[5:].strip()  # Extract PASS

                    # If we have URL, USER, and PASS, format and add to output
                    if 'url' in current_entry and 'user' in current_entry and 'pass' in current_entry:
                        output_line = f"{current_entry['url']}:{current_entry['user']}:{current_entry['pass']}"
                        output_lines.append(output_line)
                        current_entry = {}  # Reset for the next entry

    except Exception as e:
        print(f"{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}An error occurred while reading the file {file_path}: {e}{SORTER_RESET}")
        return []

    return output_lines

def find_and_sort_passwords(folder_path):
    """
    Finds 'All Passwords.txt' files in a folder and its subfolders,
    extracts and sorts password entries, and saves them to a new file.

    Args:
        folder_path (str): The path to the folder to search.
    """
    if not os.path.exists(folder_path):
        print(f"{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}Invalid folder path: {folder_path} (Folder not found){SORTER_RESET}")
        return
    if not os.path.isdir(folder_path):
        print(f"{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}Invalid path: {folder_path} (Not a folder){SORTER_RESET}")
        return

    all_output_lines = []
    found_files = 0
    files_to_process = []

    print(f"{SORTER_BLUE}{SORTER_BOLD}Searching for 'All Passwords.txt' files in: {folder_path}{SORTER_RESET}")
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower() == "all passwords.txt":
                found_files += 1
                files_to_process.append(os.path.join(root, file))

    if found_files == 0:
        print(f"{SORTER_YELLOW}{SORTER_BOLD}Warning:{SORTER_RESET} {SORTER_YELLOW}No 'All Passwords.txt' files found in the folder: {folder_path}{SORTER_RESET}")
        return

    print(f"{SORTER_MAGENTA}{SORTER_BOLD}Found {found_files} 'All Passwords.txt' files. Processing...{SORTER_RESET}")

    processed_files_count = 0
    # Use tqdm for file processing progress
    for file_path in tqdm(files_to_process, desc="Processing Files", ascii=False, ncols=100,
                          bar_format='{l_bar}{bar}{r_bar} | {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):
        processed_files_count += 1
        # percentage = (processed_files_count / found_files) * 100 # No longer needed with tqdm
        # print(f"{SORTER_CYAN}Processing file: {file_path} ({percentage:.0f}%){SORTER_RESET}") # Replaced by tqdm desc
        output_lines = sorter_txt(file_path)
        all_output_lines.extend(output_lines)

    if not all_output_lines:
        print(f"\n{SORTER_YELLOW}{SORTER_BOLD}Warning:{SORTER_RESET} {SORTER_YELLOW}No password entries found in processed files.{SORTER_RESET}") # Added newline
        return

    # Sort and remove duplicates
    all_output_lines.sort()
    # Optional: Remove duplicates if desired
    # all_output_lines = list(dict.fromkeys(all_output_lines))


    output_filename = f"x{len(all_output_lines)}_sorted_passwords_{os.path.basename(folder_path)}.txt" # Added _sorted_passwords and folder name
    output_file_path = os.path.join(folder_path, output_filename)
    try:
        with open(output_file_path, 'w', encoding='utf-8') as outfile: # Added encoding
            for line in all_output_lines:
                outfile.write(line + '\n')

        print(f"\n{SORTER_GREEN}{SORTER_BOLD}Success:{SORTER_RESET} {SORTER_GREEN}Combined and sorted output from {found_files} files saved to:{SORTER_RESET} {SORTER_GREEN}{SORTER_BOLD}{output_file_path}{SORTER_RESET}") # Added newline
        print(f"{SORTER_GREEN}Total password entries saved: {SORTER_BOLD}{len(all_output_lines)}{SORTER_RESET}")

    except Exception as e:
        print(f"\n{SORTER_RED}{SORTER_BOLD}Error:{SORTER_RESET} {SORTER_RED}An error occurred while writing to the output file: {e}{SORTER_RESET}") # Added newline


# Main execution loop
while True:
    print(f"{YELLOW_BOLD}Welcome to ComboTool!{RESET}")
    print(f"{CYAN}\n--- Multi-Functional ComboTool Menu ---{RESET}")
    print(f"{GREEN}1. Search keyword credentials (URL Remover){RESET}")
    print(f"{GREEN}2. Extract credentials from Slash URLs{RESET}")
    print(f"{GREEN}3. Extract Logs from Folder (extracted from .rar){RESET}")
    print(f"{GREEN}4. Moonton Valid Format Extractor{RESET}") # New option
    print(f"{RED}5. Exit{RESET}") # Adjusted exit option
    print(f"{CYAN}---------------------------------------{RESET}")

    choice = input(f"{GREEN}Enter your choice (1-5):{RESET} ").strip()

    if choice == '1':
        combo_file_path = get_file_path() # Prompt for file here
        if not combo_file_path:
             continue # Go back to main menu if file path is invalid

        keywords = get_keywords()
        if not keywords:  # Check if keywords list is empty after cleaning
            print(f"{RED}No valid keywords provided.{RESET}")
            print("-" * 50)
            continue

        print(f"{YELLOW_BOLD}Output files will be saved in the same directory as the combo file.{RESET}")

        for keyword in keywords:
            total_lines, output_lines, numpass_output_lines, extracted_lines, extracted_numpass_lines, lines_changed = extract_credentials_with_keyword(
                combo_file_path, keyword
            )

            # Only generate output file paths if there are extracted credentials
            if extracted_lines > 0 or extracted_numpass_lines > 0:
                if extracted_lines > 0:
                    output_file_path = generate_output_file_path(combo_file_path, extracted_lines, keyword)
                    try:
                         with open(output_file_path, 'w', encoding='utf-8') as outfile:
                            outfile.write('\n'.join(output_lines) + '\n')
                         print(f"\n{GREEN_BOLD}Credentials Successfully Extracted for Keyword: {BLUE_BOLD}{keyword}{RESET}{GREEN_BOLD}!{RESET}") # Added newline
                         print(f"{CYAN_BOLD} Saved Credentials: {extracted_lines}{RESET}")
                         print(f"{YELLOW_BOLD} Saved to: {output_file_path}{RESET}")
                    except IOError as e:
                         print(f"\n{RED}Error saving output file '{output_file_path}': {e}{RESET}") # Added newline
                         print(f"{RED} Saved Credentials: {extracted_lines} (Saving failed){RESET}")


                if extracted_numpass_lines > 0:
                    numpass_output_file_path = generate_numpass_output_file_path(combo_file_path, extracted_numpass_lines, keyword)
                    try:
                        with open(numpass_output_file_path, 'w', encoding='utf-8') as numpass_outfile:
                            numpass_outfile.write('\n'.join(numpass_output_lines) + '\n')
                        if extracted_lines == 0: # Only print success message here if no regular emails were found for this keyword
                             print(f"\n{GREEN_BOLD}Numpass Successfully Extracted for Keyword: {BLUE_BOLD}{keyword}{RESET}{GREEN_BOLD}!{RESET}") # Added newline
                        print(f"{RED_BOLD}Extracted numpass: {extracted_numpass_lines}{RESET}")
                        print(f"{YELLOW_BOLD} Saved numpass to: {numpass_output_file_path}{RESET}")
                    except IOError as e:
                        print(f"\n{RED}Error saving numpass output file '{numpass_output_file_path}': {e}{RESET}") # Added newline
                        print(f"{RED} Extracted numpass: {extracted_numpass_lines} (Saving failed){RESET}")


                print(f"{GREEN_BOLD} Total Processed Lines: {total_lines}{RESET}")
                print(f"{RED_BOLD} URLs Removed: {lines_changed}{RESET}")


            else:
                print(f"\n{RED_BOLD}No credentials found matching the keyword: {BLUE_BOLD}{keyword}{RESET}{RED_BOLD}.{RESET}") # Added newline
                print(f"{YELLOW_BOLD}Keyword: {RESET}{BLUE_BOLD}{keyword}{RESET}")
                print(f"{GREEN_BOLD} Total Processed Lines: {total_lines}{RESET}")
                print(f"{CYAN_BOLD} Saved Credentials: {extracted_lines}{RESET}")
                print(f"{RED_BOLD} URLs Removed: {lines_changed}{RESET}")

            print("-" * 50) # Separator between keyword results
        continue # Go back to main menu after processing all keywords

    elif choice == '2':
        combo_file_path = get_file_path() # Prompt for file here
        if not combo_file_path:
             continue # Go back to main menu if file path is invalid
        extract_credentials_from_slash_urls(combo_file_path)
        print("-" * 50)
        continue

    elif choice == '3':
        folder_path = get_folder_path() # Prompt for folder here
        if not folder_path:
            continue # Go back to main menu if folder path is invalid
        find_and_sort_passwords(folder_path)
        print("-" * 50)
        continue

    elif choice == '4': # Combo File Fixer
        # The process_combo_file function prompts for the file path internally.
        process_combo_file()
        print("-" * 50)
        continue

    elif choice == '5':
        print("Exiting...")
        print(f"{CYAN_BOLD}Thank You For Using Arze ComboTool!{RESET}")
        print(f"{BLUE_BOLD}Script Owner: t.me/sekiro8702{RESET}")
        break # Use break instead of exit() for clean shutdown

    else:
        print(f"{RED}Invalid choice. Please enter a number between 1 and 5.{RESET}")