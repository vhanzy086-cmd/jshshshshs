import os
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding, hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding as rsa_pad

# ========================
# AES Decryptor
# ========================
def aes_decrypt():
    try:
        ciphertext = input("Ilagay ang ciphertext (Base64): ").strip()
        ciphertext = base64.b64decode(ciphertext)
        
        key = input("Ilagay ang AES key (Base64): ").strip()
        key = base64.b64decode(key)
        
        iv = input("Ilagay ang IV (Base64): ").strip()
        iv = base64.b64decode(iv)
        
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        unpadder = padding.PKCS7(128).unpadder()
        
        decrypted = decryptor.update(ciphertext) + decryptor.finalize()
        decrypted = unpadder.update(decrypted) + unpadder.finalize()
        
        print("\n[SUCCESS!] Decrypted Data:")
        print(decrypted.decode())
    except Exception as e:
        print(f"[ERROR] {str(e)}")

# ========================
# RSA Decryptor
# ========================
def rsa_decrypt():
    try:
        ciphertext = input("Ilagay ang ciphertext (Base64): ").strip()
        ciphertext = base64.b64decode(ciphertext)
        
        key_file = input("Ilagay ang PEM private key file: ").strip()
        with open(key_file, "rb") as f:
            private_key = rsa.load_pem_private_key(f.read(), password=None)
        
        decrypted = private_key.decrypt(
            ciphertext,
            rsa_pad.OAEP(
                mgf=rsa_pad.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        print("\n[SUCCESS!] Decrypted Data:")
        print(decrypted.decode())
    except Exception as e:
        print(f"[ERROR] {str(e)}")

# ========================
# Hash Cracker (SHA256)
# ========================
def hash_cracker():
    try:
        target_hash = input("Ilagay ang target hash (hex): ").strip()
        wordlist = input("Ilagay ang wordlist file: ").strip()
        
        with open(wordlist, "r", errors="ignore") as f:
            for word in f:
                word = word.strip()
                digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
                digest.update(word.encode())
                hashed = digest.finalize().hex()
                
                if hashed == target_hash:
                    print(f"\n[CRACKED!] Password: {word}")
                    return
        print("\n[FAILED] Hindi mahanap sa wordlist.")
    except Exception as e:
        print(f"[ERROR] {str(e)}")

# ========================
# Main Menu
# ========================
def main_menu():
    os.system("clear")
    print("""
    ███████╗██████╗ ███████╗
    ██╔════╝██╔══██╗██╔════╝
    █████╗  ██║  ██║█████╗  
    ██╔══╝  ██║  ██║██╔══╝  
    ██║     ██████╔╝███████╗
    ╚═╝     ╚═════╝ ╚══════╝
    """)
    print("1. AES Decryptor")
    print("2. RSA Decryptor")
    print("3. Hash Cracker (SHA256)")
    print("4. Exit")
    
    choice = input("\nPumili ng tool (1-4): ")
    return choice

# ========================
# Run Program
# ========================
if __name__ == "__main__":
    while True:
        choice = main_menu()
        
        if choice == "1":
            aes_decrypt()
        elif choice == "2":
            rsa_decrypt()
        elif choice == "3":
            hash_cracker()
        elif choice == "4":
            print("Exit...")
            break
        else:
            print("Invalid choice!")
        
        input("\nPindutin ang Enter para magpatuloy...")